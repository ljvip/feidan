-- MySQL dump 10.13  Distrib 5.7.44, for Linux (x86_64)
--
-- Host: localhost    Database: sql_feidan_com
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_user`
--

DROP TABLE IF EXISTS `admin_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE KEY `username` (`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_user`
--

LOCK TABLES `admin_user` WRITE;
/*!40000 ALTER TABLE `admin_user` DISABLE KEYS */;
INSERT INTO `admin_user` VALUES (1,'admin','$2y$10$qUDWEUD7cIDQi5ux1QZnMuG8xTFs2W2vVX8NUXOC6i5MM7MCdZJbe',NULL,NULL,1),(6,'ce001','$2y$10$GLFPdxxb8cFxeW6ULitFp.PEEXsFM/jAVUh8coJcbbMbgnuu7o6FS','2024-04-22 14:49:38','2024-04-22 15:44:48',1),(7,'ce002','$2y$10$k2zp7Fso9v55xTaoHIiSNeARQmHZUsffyNx1ZDnuWYzpUT2LVwj0a','2024-04-22 14:49:52',NULL,1),(8,'ce003','$2y$10$/xFePK0AR87UKFDOnFJupOIureo9BDOWZnQ1i9v37PfvTaID4g3b.','2024-04-22 15:45:19','2024-04-22 15:48:57',1);
/*!40000 ALTER TABLE `admin_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `platform`
--

DROP TABLE IF EXISTS `platform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platform` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_user_id` int(11) NOT NULL DEFAULT '0',
  `platform_name` varchar(255) DEFAULT NULL COMMENT '平台名称',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '对接地址',
  `username` varchar(255) NOT NULL DEFAULT '' COMMENT '用户名',
  `password` varchar(255) NOT NULL DEFAULT '' COMMENT '密码',
  `ce` varchar(200) NOT NULL DEFAULT '',
  `redouble` int(10) unsigned NOT NULL DEFAULT '100' COMMENT '飞单加倍 100% 不加倍',
  `redouble_profit` int(10) NOT NULL DEFAULT '50000' COMMENT '加倍止盈',
  `redouble_loss` int(10) NOT NULL DEFAULT '50000' COMMENT '加倍止损',
  `token` varchar(255) NOT NULL DEFAULT '' COMMENT 'token',
  `online` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 在线 0 离线',
  `offline_reason` longtext COMMENT '离线原因',
  `auto_login` tinyint(1) NOT NULL DEFAULT '0' COMMENT '自动重连 1 开启 0 关闭',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '1 启动 0 禁用',
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `balance` varchar(100) NOT NULL DEFAULT '0.00' COMMENT '当前余额',
  `betting` varchar(100) NOT NULL DEFAULT '0.00' COMMENT '当前未结算',
  `result` varchar(100) NOT NULL DEFAULT '0.00' COMMENT '收益',
  `polling` int(11) NOT NULL DEFAULT '0' COMMENT '轮训次数 默认使用次数最少的',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `platform`
--

LOCK TABLES `platform` WRITE;
/*!40000 ALTER TABLE `platform` DISABLE KEYS */;
INSERT INTO `platform` VALUES (37,6,'cf','https://0629157483-jc.for9dong.com','nba909','Aass1122','',100,50000,50000,'4d6cecfabb239e9ced5140d6b844f75379aedf99',1,'',1,1,'2024-04-23 16:05:41','2024-04-24 21:43:57','300','0','0',32);
/*!40000 ALTER TABLE `platform` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `platform_log`
--

DROP TABLE IF EXISTS `platform_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platform_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_user_id` int(11) NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL DEFAULT '',
  `username` varchar(255) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `send` json DEFAULT NULL COMMENT '发送数据',
  `input` json DEFAULT NULL COMMENT '接受数据',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4 ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `platform_log`
--

LOCK TABLES `platform_log` WRITE;
/*!40000 ALTER TABLE `platform_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `platform_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'sql_feidan_com'
--

--
-- Dumping routines for database 'sql_feidan_com'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-24 21:46:10
